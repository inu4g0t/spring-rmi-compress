import java.util.ArrayList;

/**
 * Created by youli on 2017/2/7.
 */
public interface Calculation {
    ArrayList<Integer> cube(int number);
}
